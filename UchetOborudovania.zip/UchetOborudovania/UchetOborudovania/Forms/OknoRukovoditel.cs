﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UchetOborudovania
{
    public partial class OknoRukovoditel : Form
    {
        public DataSet ds = new DataSet();

        public OknoRukovoditel()
        {
            InitializeComponent();
        }

        private void buttonNazad_Click(object sender, EventArgs e)
        {
            OknoAvtorizacia oknoAvtorizacia = new OknoAvtorizacia();
            oknoAvtorizacia.Show();
            this.Close();
        }

        private void OknoRukovoditel_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "uchetOborudovaniaDataSet2.Sotrudniki". При необходимости она может быть перемещена или удалена.
            this.sotrudnikiTableAdapter.Fill(this.uchetOborudovaniaDataSet2.Sotrudniki);

            // Изменение ФИО и фотографии сотрудника в зависимости от введённого логина и пароля

            labelFIO.Text = ds.Tables[0].Rows[0][1].ToString();

            byte[] foto = null;

            foto = (byte[])ds.Tables[0].Rows[0][6];

            using (MemoryStream ms = new MemoryStream(foto))
            {
                Image originalFoto = Image.FromStream(ms);
                pictureBox1.Image = new Bitmap(originalFoto, new Size(117, 98));
            }

        }
    }
}
