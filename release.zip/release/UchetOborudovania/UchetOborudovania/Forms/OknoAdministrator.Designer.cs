﻿namespace UchetOborudovania
{
    partial class OknoAdministrator
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OknoAdministrator));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonPoisk = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idOborudovaniaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fotoDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.seriyniyNomerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.naimenovanieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opisanieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomerKabinetaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idSotrudnikaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oborudovanieBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uchetOborudovaniaDataSet = new UchetOborudovania.UchetOborudovaniaDataSet();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.idIstoriiVhodaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idSotrudnikaDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataVremaPopitkiVhodaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.istoriaVhodaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uchetOborudovaniaDataSet1 = new UchetOborudovania.UchetOborudovaniaDataSet1();
            this.buttonNazad = new System.Windows.Forms.Button();
            this.labelFIO = new System.Windows.Forms.Label();
            this.oborudovanieTableAdapter = new UchetOborudovania.UchetOborudovaniaDataSetTableAdapters.OborudovanieTableAdapter();
            this.istoriaVhodaTableAdapter = new UchetOborudovania.UchetOborudovaniaDataSet1TableAdapters.IstoriaVhodaTableAdapter();
            this.pictureBoxKrasniyKrug1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxKrasniyKrug2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxKrasniyKrug3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxKrasniyKrug4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxKrasniyKrug5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxKrasniyKrug6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxZeleniyKrug1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxZeleniyKrug2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxZeleniyKrug3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxZeleniyKrug4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxZeleniyKrug5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxZeleniyKrug6 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oborudovanieBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uchetOborudovaniaDataSet)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.istoriaVhodaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uchetOborudovaniaDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug6)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(358, 77);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Окно.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(467, 77);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(210, 31);
            this.label2.TabIndex = 2;
            this.label2.Text = "Администратор";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(14, 160);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(905, 698);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.tabPage1.Controls.Add(this.pictureBoxZeleniyKrug6);
            this.tabPage1.Controls.Add(this.pictureBoxZeleniyKrug5);
            this.tabPage1.Controls.Add(this.pictureBoxZeleniyKrug4);
            this.tabPage1.Controls.Add(this.pictureBoxZeleniyKrug3);
            this.tabPage1.Controls.Add(this.pictureBoxZeleniyKrug2);
            this.tabPage1.Controls.Add(this.pictureBoxZeleniyKrug1);
            this.tabPage1.Controls.Add(this.pictureBoxKrasniyKrug6);
            this.tabPage1.Controls.Add(this.pictureBoxKrasniyKrug5);
            this.tabPage1.Controls.Add(this.pictureBoxKrasniyKrug4);
            this.tabPage1.Controls.Add(this.pictureBoxKrasniyKrug3);
            this.tabPage1.Controls.Add(this.pictureBoxKrasniyKrug2);
            this.tabPage1.Controls.Add(this.pictureBoxKrasniyKrug1);
            this.tabPage1.Controls.Add(this.buttonPoisk);
            this.tabPage1.Controls.Add(this.dataGridView3);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage1.Size = new System.Drawing.Size(897, 670);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Оборудование";
            // 
            // buttonPoisk
            // 
            this.buttonPoisk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.buttonPoisk.Location = new System.Drawing.Point(11, 331);
            this.buttonPoisk.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonPoisk.Name = "buttonPoisk";
            this.buttonPoisk.Size = new System.Drawing.Size(155, 51);
            this.buttonPoisk.TabIndex = 9;
            this.buttonPoisk.Text = "Найти";
            this.buttonPoisk.UseVisualStyleBackColor = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(477, 422);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(412, 207);
            this.dataGridView3.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 395);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Результаты поиска:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(11, 293);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(395, 23);
            this.textBox1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 265);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(361, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Введите серийный номер оборудования для выполнения поиска:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idOborudovaniaDataGridViewTextBoxColumn,
            this.fotoDataGridViewImageColumn,
            this.seriyniyNomerDataGridViewTextBoxColumn,
            this.naimenovanieDataGridViewTextBoxColumn,
            this.opisanieDataGridViewTextBoxColumn,
            this.nomerKabinetaDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.idSotrudnikaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.oborudovanieBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(8, 20);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(881, 228);
            this.dataGridView1.TabIndex = 0;
            // 
            // idOborudovaniaDataGridViewTextBoxColumn
            // 
            this.idOborudovaniaDataGridViewTextBoxColumn.DataPropertyName = "IdOborudovania";
            this.idOborudovaniaDataGridViewTextBoxColumn.HeaderText = "IdOborudovania";
            this.idOborudovaniaDataGridViewTextBoxColumn.Name = "idOborudovaniaDataGridViewTextBoxColumn";
            // 
            // fotoDataGridViewImageColumn
            // 
            this.fotoDataGridViewImageColumn.DataPropertyName = "Foto";
            this.fotoDataGridViewImageColumn.HeaderText = "Foto";
            this.fotoDataGridViewImageColumn.Name = "fotoDataGridViewImageColumn";
            // 
            // seriyniyNomerDataGridViewTextBoxColumn
            // 
            this.seriyniyNomerDataGridViewTextBoxColumn.DataPropertyName = "SeriyniyNomer";
            this.seriyniyNomerDataGridViewTextBoxColumn.HeaderText = "SeriyniyNomer";
            this.seriyniyNomerDataGridViewTextBoxColumn.Name = "seriyniyNomerDataGridViewTextBoxColumn";
            // 
            // naimenovanieDataGridViewTextBoxColumn
            // 
            this.naimenovanieDataGridViewTextBoxColumn.DataPropertyName = "Naimenovanie";
            this.naimenovanieDataGridViewTextBoxColumn.HeaderText = "Naimenovanie";
            this.naimenovanieDataGridViewTextBoxColumn.Name = "naimenovanieDataGridViewTextBoxColumn";
            // 
            // opisanieDataGridViewTextBoxColumn
            // 
            this.opisanieDataGridViewTextBoxColumn.DataPropertyName = "Opisanie";
            this.opisanieDataGridViewTextBoxColumn.HeaderText = "Opisanie";
            this.opisanieDataGridViewTextBoxColumn.Name = "opisanieDataGridViewTextBoxColumn";
            // 
            // nomerKabinetaDataGridViewTextBoxColumn
            // 
            this.nomerKabinetaDataGridViewTextBoxColumn.DataPropertyName = "NomerKabineta";
            this.nomerKabinetaDataGridViewTextBoxColumn.HeaderText = "NomerKabineta";
            this.nomerKabinetaDataGridViewTextBoxColumn.Name = "nomerKabinetaDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // idSotrudnikaDataGridViewTextBoxColumn
            // 
            this.idSotrudnikaDataGridViewTextBoxColumn.DataPropertyName = "IdSotrudnika";
            this.idSotrudnikaDataGridViewTextBoxColumn.HeaderText = "IdSotrudnika";
            this.idSotrudnikaDataGridViewTextBoxColumn.Name = "idSotrudnikaDataGridViewTextBoxColumn";
            // 
            // oborudovanieBindingSource
            // 
            this.oborudovanieBindingSource.DataMember = "Oborudovanie";
            this.oborudovanieBindingSource.DataSource = this.uchetOborudovaniaDataSet;
            // 
            // uchetOborudovaniaDataSet
            // 
            this.uchetOborudovaniaDataSet.DataSetName = "UchetOborudovaniaDataSet";
            this.uchetOborudovaniaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabPage2.Size = new System.Drawing.Size(897, 670);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "История входа";
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idIstoriiVhodaDataGridViewTextBoxColumn,
            this.idSotrudnikaDataGridViewTextBoxColumn1,
            this.dataVremaPopitkiVhodaDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.istoriaVhodaBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(8, 29);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(881, 318);
            this.dataGridView2.TabIndex = 1;
            // 
            // idIstoriiVhodaDataGridViewTextBoxColumn
            // 
            this.idIstoriiVhodaDataGridViewTextBoxColumn.DataPropertyName = "IdIstoriiVhoda";
            this.idIstoriiVhodaDataGridViewTextBoxColumn.HeaderText = "IdIstoriiVhoda";
            this.idIstoriiVhodaDataGridViewTextBoxColumn.Name = "idIstoriiVhodaDataGridViewTextBoxColumn";
            // 
            // idSotrudnikaDataGridViewTextBoxColumn1
            // 
            this.idSotrudnikaDataGridViewTextBoxColumn1.DataPropertyName = "IdSotrudnika";
            this.idSotrudnikaDataGridViewTextBoxColumn1.HeaderText = "IdSotrudnika";
            this.idSotrudnikaDataGridViewTextBoxColumn1.Name = "idSotrudnikaDataGridViewTextBoxColumn1";
            // 
            // dataVremaPopitkiVhodaDataGridViewTextBoxColumn
            // 
            this.dataVremaPopitkiVhodaDataGridViewTextBoxColumn.DataPropertyName = "DataVremaPopitkiVhoda";
            this.dataVremaPopitkiVhodaDataGridViewTextBoxColumn.HeaderText = "DataVremaPopitkiVhoda";
            this.dataVremaPopitkiVhodaDataGridViewTextBoxColumn.Name = "dataVremaPopitkiVhodaDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn1
            // 
            this.statusDataGridViewTextBoxColumn1.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn1.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn1.Name = "statusDataGridViewTextBoxColumn1";
            // 
            // istoriaVhodaBindingSource
            // 
            this.istoriaVhodaBindingSource.DataMember = "IstoriaVhoda";
            this.istoriaVhodaBindingSource.DataSource = this.uchetOborudovaniaDataSet1;
            // 
            // uchetOborudovaniaDataSet1
            // 
            this.uchetOborudovaniaDataSet1.DataSetName = "UchetOborudovaniaDataSet1";
            this.uchetOborudovaniaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonNazad
            // 
            this.buttonNazad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.buttonNazad.Location = new System.Drawing.Point(14, 877);
            this.buttonNazad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonNazad.Name = "buttonNazad";
            this.buttonNazad.Size = new System.Drawing.Size(155, 30);
            this.buttonNazad.TabIndex = 10;
            this.buttonNazad.Text = "Назад";
            this.buttonNazad.UseVisualStyleBackColor = false;
            this.buttonNazad.Click += new System.EventHandler(this.buttonNazad_Click);
            // 
            // labelFIO
            // 
            this.labelFIO.AutoSize = true;
            this.labelFIO.Location = new System.Drawing.Point(377, 125);
            this.labelFIO.Name = "labelFIO";
            this.labelFIO.Size = new System.Drawing.Size(179, 15);
            this.labelFIO.TabIndex = 11;
            this.labelFIO.Text = "Мясников Власий Лаврентьевич";
            // 
            // oborudovanieTableAdapter
            // 
            this.oborudovanieTableAdapter.ClearBeforeFill = true;
            // 
            // istoriaVhodaTableAdapter
            // 
            this.istoriaVhodaTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBoxKrasniyKrug1
            // 
            this.pictureBoxKrasniyKrug1.BackColor = System.Drawing.Color.White;
            this.pictureBoxKrasniyKrug1.BackgroundImage = global::UchetOborudovania.Properties.Resources.KrasniyKrug;
            this.pictureBoxKrasniyKrug1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxKrasniyKrug1.Location = new System.Drawing.Point(21, 440);
            this.pictureBoxKrasniyKrug1.Name = "pictureBoxKrasniyKrug1";
            this.pictureBoxKrasniyKrug1.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxKrasniyKrug1.TabIndex = 10;
            this.pictureBoxKrasniyKrug1.TabStop = false;
            this.pictureBoxKrasniyKrug1.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::UchetOborudovania.Properties.Resources.cabin;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(11, 422);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(438, 207);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::UchetOborudovania.Properties.Resources.Logo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(223, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(117, 98);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBoxKrasniyKrug2
            // 
            this.pictureBoxKrasniyKrug2.BackColor = System.Drawing.Color.White;
            this.pictureBoxKrasniyKrug2.BackgroundImage = global::UchetOborudovania.Properties.Resources.KrasniyKrug;
            this.pictureBoxKrasniyKrug2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxKrasniyKrug2.Location = new System.Drawing.Point(167, 440);
            this.pictureBoxKrasniyKrug2.Name = "pictureBoxKrasniyKrug2";
            this.pictureBoxKrasniyKrug2.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxKrasniyKrug2.TabIndex = 11;
            this.pictureBoxKrasniyKrug2.TabStop = false;
            this.pictureBoxKrasniyKrug2.Visible = false;
            // 
            // pictureBoxKrasniyKrug3
            // 
            this.pictureBoxKrasniyKrug3.BackColor = System.Drawing.Color.White;
            this.pictureBoxKrasniyKrug3.BackgroundImage = global::UchetOborudovania.Properties.Resources.KrasniyKrug;
            this.pictureBoxKrasniyKrug3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxKrasniyKrug3.Location = new System.Drawing.Point(314, 440);
            this.pictureBoxKrasniyKrug3.Name = "pictureBoxKrasniyKrug3";
            this.pictureBoxKrasniyKrug3.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxKrasniyKrug3.TabIndex = 12;
            this.pictureBoxKrasniyKrug3.TabStop = false;
            this.pictureBoxKrasniyKrug3.Visible = false;
            // 
            // pictureBoxKrasniyKrug4
            // 
            this.pictureBoxKrasniyKrug4.BackColor = System.Drawing.Color.White;
            this.pictureBoxKrasniyKrug4.BackgroundImage = global::UchetOborudovania.Properties.Resources.KrasniyKrug;
            this.pictureBoxKrasniyKrug4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxKrasniyKrug4.Location = new System.Drawing.Point(21, 560);
            this.pictureBoxKrasniyKrug4.Name = "pictureBoxKrasniyKrug4";
            this.pictureBoxKrasniyKrug4.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxKrasniyKrug4.TabIndex = 13;
            this.pictureBoxKrasniyKrug4.TabStop = false;
            this.pictureBoxKrasniyKrug4.Visible = false;
            // 
            // pictureBoxKrasniyKrug5
            // 
            this.pictureBoxKrasniyKrug5.BackColor = System.Drawing.Color.White;
            this.pictureBoxKrasniyKrug5.BackgroundImage = global::UchetOborudovania.Properties.Resources.KrasniyKrug;
            this.pictureBoxKrasniyKrug5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxKrasniyKrug5.Location = new System.Drawing.Point(167, 560);
            this.pictureBoxKrasniyKrug5.Name = "pictureBoxKrasniyKrug5";
            this.pictureBoxKrasniyKrug5.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxKrasniyKrug5.TabIndex = 14;
            this.pictureBoxKrasniyKrug5.TabStop = false;
            this.pictureBoxKrasniyKrug5.Visible = false;
            // 
            // pictureBoxKrasniyKrug6
            // 
            this.pictureBoxKrasniyKrug6.BackColor = System.Drawing.Color.White;
            this.pictureBoxKrasniyKrug6.BackgroundImage = global::UchetOborudovania.Properties.Resources.KrasniyKrug;
            this.pictureBoxKrasniyKrug6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxKrasniyKrug6.Location = new System.Drawing.Point(305, 560);
            this.pictureBoxKrasniyKrug6.Name = "pictureBoxKrasniyKrug6";
            this.pictureBoxKrasniyKrug6.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxKrasniyKrug6.TabIndex = 15;
            this.pictureBoxKrasniyKrug6.TabStop = false;
            this.pictureBoxKrasniyKrug6.Visible = false;
            // 
            // pictureBoxZeleniyKrug1
            // 
            this.pictureBoxZeleniyKrug1.BackColor = System.Drawing.Color.White;
            this.pictureBoxZeleniyKrug1.BackgroundImage = global::UchetOborudovania.Properties.Resources.ZeleniyKrug;
            this.pictureBoxZeleniyKrug1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxZeleniyKrug1.Location = new System.Drawing.Point(21, 440);
            this.pictureBoxZeleniyKrug1.Name = "pictureBoxZeleniyKrug1";
            this.pictureBoxZeleniyKrug1.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxZeleniyKrug1.TabIndex = 16;
            this.pictureBoxZeleniyKrug1.TabStop = false;
            this.pictureBoxZeleniyKrug1.Visible = false;
            // 
            // pictureBoxZeleniyKrug2
            // 
            this.pictureBoxZeleniyKrug2.BackColor = System.Drawing.Color.White;
            this.pictureBoxZeleniyKrug2.BackgroundImage = global::UchetOborudovania.Properties.Resources.ZeleniyKrug;
            this.pictureBoxZeleniyKrug2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxZeleniyKrug2.Location = new System.Drawing.Point(167, 440);
            this.pictureBoxZeleniyKrug2.Name = "pictureBoxZeleniyKrug2";
            this.pictureBoxZeleniyKrug2.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxZeleniyKrug2.TabIndex = 17;
            this.pictureBoxZeleniyKrug2.TabStop = false;
            this.pictureBoxZeleniyKrug2.Visible = false;
            // 
            // pictureBoxZeleniyKrug3
            // 
            this.pictureBoxZeleniyKrug3.BackColor = System.Drawing.Color.White;
            this.pictureBoxZeleniyKrug3.BackgroundImage = global::UchetOborudovania.Properties.Resources.ZeleniyKrug;
            this.pictureBoxZeleniyKrug3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxZeleniyKrug3.Location = new System.Drawing.Point(314, 440);
            this.pictureBoxZeleniyKrug3.Name = "pictureBoxZeleniyKrug3";
            this.pictureBoxZeleniyKrug3.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxZeleniyKrug3.TabIndex = 18;
            this.pictureBoxZeleniyKrug3.TabStop = false;
            this.pictureBoxZeleniyKrug3.Visible = false;
            // 
            // pictureBoxZeleniyKrug4
            // 
            this.pictureBoxZeleniyKrug4.BackColor = System.Drawing.Color.White;
            this.pictureBoxZeleniyKrug4.BackgroundImage = global::UchetOborudovania.Properties.Resources.ZeleniyKrug;
            this.pictureBoxZeleniyKrug4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxZeleniyKrug4.Location = new System.Drawing.Point(21, 560);
            this.pictureBoxZeleniyKrug4.Name = "pictureBoxZeleniyKrug4";
            this.pictureBoxZeleniyKrug4.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxZeleniyKrug4.TabIndex = 19;
            this.pictureBoxZeleniyKrug4.TabStop = false;
            this.pictureBoxZeleniyKrug4.Visible = false;
            // 
            // pictureBoxZeleniyKrug5
            // 
            this.pictureBoxZeleniyKrug5.BackColor = System.Drawing.Color.White;
            this.pictureBoxZeleniyKrug5.BackgroundImage = global::UchetOborudovania.Properties.Resources.ZeleniyKrug;
            this.pictureBoxZeleniyKrug5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxZeleniyKrug5.Location = new System.Drawing.Point(167, 560);
            this.pictureBoxZeleniyKrug5.Name = "pictureBoxZeleniyKrug5";
            this.pictureBoxZeleniyKrug5.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxZeleniyKrug5.TabIndex = 20;
            this.pictureBoxZeleniyKrug5.TabStop = false;
            this.pictureBoxZeleniyKrug5.Visible = false;
            // 
            // pictureBoxZeleniyKrug6
            // 
            this.pictureBoxZeleniyKrug6.BackColor = System.Drawing.Color.White;
            this.pictureBoxZeleniyKrug6.BackgroundImage = global::UchetOborudovania.Properties.Resources.ZeleniyKrug;
            this.pictureBoxZeleniyKrug6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxZeleniyKrug6.Location = new System.Drawing.Point(305, 560);
            this.pictureBoxZeleniyKrug6.Name = "pictureBoxZeleniyKrug6";
            this.pictureBoxZeleniyKrug6.Size = new System.Drawing.Size(40, 39);
            this.pictureBoxZeleniyKrug6.TabIndex = 21;
            this.pictureBoxZeleniyKrug6.TabStop = false;
            this.pictureBoxZeleniyKrug6.Visible = false;
            // 
            // OknoAdministrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(933, 918);
            this.Controls.Add(this.labelFIO);
            this.Controls.Add(this.buttonNazad);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MinimumSize = new System.Drawing.Size(949, 957);
            this.Name = "OknoAdministrator";
            this.Text = "Окно. Администратор";
            this.Load += new System.EventHandler(this.OknoAdministrator_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oborudovanieBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uchetOborudovaniaDataSet)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.istoriaVhodaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uchetOborudovaniaDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKrasniyKrug6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxZeleniyKrug6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonPoisk;
        private System.Windows.Forms.Button buttonNazad;
        private System.Windows.Forms.Label labelFIO;
        private UchetOborudovaniaDataSet uchetOborudovaniaDataSet;
        private System.Windows.Forms.BindingSource oborudovanieBindingSource;
        private UchetOborudovaniaDataSetTableAdapters.OborudovanieTableAdapter oborudovanieTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idOborudovaniaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn fotoDataGridViewImageColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seriyniyNomerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn naimenovanieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn opisanieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomerKabinetaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSotrudnikaDataGridViewTextBoxColumn;
        private UchetOborudovaniaDataSet1 uchetOborudovaniaDataSet1;
        private System.Windows.Forms.BindingSource istoriaVhodaBindingSource;
        private UchetOborudovaniaDataSet1TableAdapters.IstoriaVhodaTableAdapter istoriaVhodaTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idIstoriiVhodaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSotrudnikaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataVremaPopitkiVhodaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn1;
        private System.Windows.Forms.PictureBox pictureBoxKrasniyKrug1;
        private System.Windows.Forms.PictureBox pictureBoxKrasniyKrug6;
        private System.Windows.Forms.PictureBox pictureBoxKrasniyKrug5;
        private System.Windows.Forms.PictureBox pictureBoxKrasniyKrug4;
        private System.Windows.Forms.PictureBox pictureBoxKrasniyKrug3;
        private System.Windows.Forms.PictureBox pictureBoxKrasniyKrug2;
        private System.Windows.Forms.PictureBox pictureBoxZeleniyKrug6;
        private System.Windows.Forms.PictureBox pictureBoxZeleniyKrug5;
        private System.Windows.Forms.PictureBox pictureBoxZeleniyKrug4;
        private System.Windows.Forms.PictureBox pictureBoxZeleniyKrug3;
        private System.Windows.Forms.PictureBox pictureBoxZeleniyKrug2;
        private System.Windows.Forms.PictureBox pictureBoxZeleniyKrug1;
    }
}

